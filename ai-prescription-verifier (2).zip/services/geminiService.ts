import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { AnalysisResult, ChatMessage } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result.split(',')[1]);
      }
    };
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        patientName: { type: Type.STRING, nullable: true, description: 'The name of the patient, if found.' },
        drugs: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: 'The name of the drug.' },
                    dosage: { type: Type.STRING, description: 'The dosage, e.g., "100mg".' },
                    frequency: { type: Type.STRING, description: 'How often to take the drug, e.g., "twice daily".' },
                    quantity: { type: Type.STRING, nullable: true, description: 'The total quantity prescribed.' },
                },
                required: ['name', 'dosage', 'frequency'],
            },
        },
        dosageVerification: {
            type: Type.OBJECT,
            properties: {
                isCorrect: { type: Type.BOOLEAN, description: 'Whether the dosage is within standard medical guidelines for the patient.' },
                explanation: { type: Type.STRING, description: 'A brief explanation of the dosage verification.' },
            },
            required: ['isCorrect', 'explanation'],
        },
        interactionAlert: {
            type: Type.OBJECT,
            properties: {
                level: { type: Type.STRING, enum: ['Safe', 'Warning', 'Severe'], description: 'The severity level of potential drug interactions.' },
                explanation: { type: Type.STRING, description: 'A clear, concise explanation of any potential interactions.' },
            },
            required: ['level', 'explanation'],
        },
        alternativeSuggestions: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    originalDrug: { type: Type.STRING },
                    alternativeDrug: { type: Type.STRING },
                    reason: { type: Type.STRING, description: 'The reason for suggesting the alternative (e.g., safer, cheaper, fewer side effects).' },
                },
                required: ['originalDrug', 'alternativeDrug', 'reason'],
            },
        },
        healthScore: { 
            type: Type.NUMBER, 
            description: 'A numerical score from 0 to 100 representing the overall safety and appropriateness of the prescription, where 100 is excellent. Factor in interactions, dosage correctness, allergies, and conditions.' 
        },
        sideEffects: {
            type: Type.OBJECT,
            properties: {
                common: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A list of common, less severe side effects.'},
                serious: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A list of serious side effects that require medical attention.'}
            },
            required: ['common', 'serious']
        },
        lifestyleSuggestions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'A list of non-drug health and lifestyle recommendations relevant to the patient\'s condition (e.g., diet tips for a cholesterol medicine).'
        },
        medicineAvailability: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    drugName: { type: Type.STRING },
                    pharmacy: { type: Type.STRING, description: 'Mock pharmacy name (e.g., Apollo, PharmEasy).' },
                    price: { type: Type.STRING, description: 'Mock price in INR (e.g., "₹150.00").' },
                    availability: { type: Type.STRING, enum: ['In Stock', 'Low Stock', 'Out of Stock'] },
                    distance: { type: Type.STRING, description: 'Mock distance (e.g., "1.2 km").' }
                },
                required: ['drugName', 'pharmacy', 'price', 'availability', 'distance']
            },
            description: 'Mock data for medicine availability and pricing for each prescribed drug.'
        },
        medicineReminders: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    drugName: { type: Type.STRING },
                    reminderTimes: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A list of reminder times, e.g., ["8:00 AM", "8:00 PM"].' },
                    instructions: { type: Type.STRING, description: 'Simple instructions like "with food" or "before bed".' }
                },
                required: ['drugName', 'reminderTimes', 'instructions']
            },
            description: 'A schedule of medicine reminders based on the prescribed frequency.'
        }
    },
    required: ['drugs', 'dosageVerification', 'interactionAlert', 'alternativeSuggestions', 'healthScore', 'sideEffects', 'lifestyleSuggestions', 'medicineAvailability', 'medicineReminders'],
};

const languageMap: { [key: string]: string } = {
    en: 'English',
    hi: 'Hindi',
    te: 'Telugu',
    ta: 'Tamil',
};

export const analyzePrescription = async (
  file: File | null,
  text: string,
  name: string,
  age: number,
  gender: string,
  allergies: string,
  conditions: string,
  language: string
): Promise<AnalysisResult> => {
  const targetLanguage = languageMap[language] || 'English';
  
  const prompt = `
    You are an expert AI medical assistant. Analyze the following prescription for patient "${name}", a ${age}-year-old ${gender}.
    
    Patient Context:
    - Known Allergies: ${allergies || 'None specified'}
    - Pre-existing Conditions: ${conditions || 'None specified'}

    Instructions:
    1.  **Parse Prescription:** Extract all drugs, including their name, dosage, and frequency from the provided prescription data.
    2.  **Verify Dosage:** Based on standard medical guidelines for the patient's age, gender, and conditions, verify if the dosages are correct. Flag any that are unusual.
    3.  **Check Interactions:** Check for potential drug-drug interactions. More importantly, check for contraindications based on the patient's specified allergies and pre-existing conditions.
    4.  **Suggest Alternatives:** If there are significant risks, suggest safer alternative medications.
    5.  **Predict Side Effects:** List potential common and serious side effects for the prescribed drugs.
    6.  **Provide Lifestyle Advice:** Based on the likely condition being treated (e.g., high cholesterol, diabetes), provide 2-3 relevant non-drug health and lifestyle suggestions.
    7.  **Generate Health Score:** Calculate a "Prescription Health Score" from 0-100. Start at 100 and deduct points for: severe interactions (-40), warning interactions (-20), incorrect dosage (-25), contraindications due to allergies/conditions (-50).
    8.  **Mock Pharmacy Data:** For each drug, create 1-2 mock entries for its availability and price in Indian pharmacies (like Apollo, Netmeds).
    9.  **Generate Reminders:** Create a simple medicine reminder schedule based on the prescribed frequency. For each drug, provide specific times (e.g., 'daily' -> '9:00 AM', 'twice daily' -> '9:00 AM & 9:00 PM') and a brief, relevant instruction (e.g., 'with food', 'before sleeping').
    10. **Language:** Provide all textual explanations (like dosage verification, interaction explanations, alternative reasons, side effects, lifestyle suggestions) in ${targetLanguage}. The JSON keys must remain in English.
    11. **Return JSON:** Return the entire comprehensive analysis in the specified JSON format. Ensure all fields are populated. Do not add any commentary outside of the JSON structure.

    Prescription Data is provided below.
  `;
  
  const parts: ({ text: string; } | { inlineData: { data: string; mimeType: string; } })[] = [{ text: prompt }];

  if (file) {
    const filePart = await fileToGenerativePart(file);
    parts.push(filePart);
  } else if (text) {
    parts.push({ text: `\n--- PRESCRIPTION TEXT --- \n${text}` });
  } else {
    throw new Error('No prescription data provided.');
  }

  try {
    const result: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts
        },
        config: {
            responseMimeType: 'application/json',
            responseSchema: analysisSchema
        }
    });

    const jsonText = result.text.trim();
    return JSON.parse(jsonText) as AnalysisResult;

  } catch (error) {
    console.error("Error analyzing prescription:", error);
    throw new Error("Failed to analyze prescription. The AI model may have returned an invalid response. Please ensure the prescription is clear.");
  }
};


export const sendMessageToChat = async (
    history: ChatMessage[],
    analysisContext: AnalysisResult
): Promise<AsyncGenerator<GenerateContentResponse>> => {
    
    const geminiHistory = history.slice(0, -1).map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
    }));

    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        history: geminiHistory,
        config: {
            systemInstruction: `You are a helpful AI medical assistant. The user has just analyzed a prescription with the following results: ${JSON.stringify(analysisContext)}. 
            Your role is to answer their follow-up questions concisely and clearly based on this context. 
            Do not give definitive medical advice. Always conclude by advising the user to consult a real healthcare professional for final decisions.`
        }
    });
    
    const lastMessage = history[history.length - 1];
    
    try {
        const stream = await chat.sendMessageStream({ message: lastMessage.text });
        return stream;
    } catch (error) {
        console.error("Error sending chat message:", error);
        throw new Error("Failed to get response from chatbot.");
    }
};