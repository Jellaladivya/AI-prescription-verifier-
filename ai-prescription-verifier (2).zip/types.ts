export enum View {
  Analysis = 'Analysis',
  PatientDrafts = 'Patient Drafts',
  DoctorsDirectory = 'Doctors Directory',
}

export enum InteractionLevel {
    Safe = 'Safe',
    Warning = 'Warning',
    Severe = 'Severe'
}

export interface DrugInfo {
    name: string;
    dosage: string;
    frequency: string;
    quantity: string | null;
}

export interface DosageVerification {
    isCorrect: boolean;
    explanation: string;
}

export interface InteractionAlert {
    level: InteractionLevel;
    explanation: string;
}

export interface AlternativeSuggestion {
    originalDrug: string;
    alternativeDrug: string;
    reason: string;
}

export interface MedicineAvailability {
    drugName: string;
    pharmacy: string;
    price: string;
    availability: 'In Stock' | 'Low Stock' | 'Out of Stock';
    distance: string;
}

export interface MedicineReminder {
    drugName: string;
    reminderTimes: string[];
    instructions: string;
}

export interface AnalysisResult {
    patientName: string | null;
    drugs: DrugInfo[];
    dosageVerification: DosageVerification;
    interactionAlert: InteractionAlert;
    alternativeSuggestions: AlternativeSuggestion[];
    healthScore: number;
    sideEffects: {
        common: string[];
        serious: string[];
    };
    lifestyleSuggestions: string[];
    medicineAvailability: MedicineAvailability[];
    medicineReminders: MedicineReminder[];
}

export interface ChatMessage {
    role: 'user' | 'model';
    text: string;
}

export interface PatientDraft {
  id: string;
  date: string;
  patient: string; // "John Smith, Age 45, Male"
  prescriptionSummary: string; // "Atorvastatin 20mg, ..."
  analysis: AnalysisResult;
}