
import React from 'react';
import { View } from '../types';
import { AnalysisIcon, RecordsIcon, DirectoryIcon, LogoutIcon } from './icons';

interface SidebarProps {
  currentView: View;
  setCurrentView: (view: View) => void;
  onLogout: () => void;
  user: { name: string; email: string } | null;
  language: string;
  setLanguage: (lang: 'en' | 'hi' | 'te' | 'ta') => void;
}

const languageOptions = {
    en: 'English',
    hi: 'हिन्दी',
    te: 'తెలుగు',
    ta: 'தமிழ்'
};


const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView, onLogout, user, language, setLanguage }) => {
  const navItems = [
    { view: View.Analysis, icon: AnalysisIcon, label: 'Analysis' },
    { view: View.PatientDrafts, icon: RecordsIcon, label: 'Patient Drafts' },
    { view: View.DoctorsDirectory, icon: DirectoryIcon, label: 'Doctors Directory' },
  ];

  return (
    <div className="w-16 sm:w-64 bg-white shadow-lg flex flex-col">
      <div className="flex items-center justify-center sm:justify-start h-20 border-b p-4 sm:px-6">
        <svg className="h-8 w-8 text-brand-blue" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
        </svg>
        <h1 className="hidden sm:block text-xl font-bold text-brand-blue-dark ml-3">AI Prescription Verifier</h1>
      </div>
      <nav className="flex-1 px-2 sm:px-4 py-4 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.view}
            onClick={() => setCurrentView(item.view)}
            className={`flex items-center justify-center sm:justify-start p-3 w-full text-sm font-medium rounded-lg transition-colors duration-200 ${
              currentView === item.view
                ? 'bg-brand-blue-light text-brand-blue-dark'
                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
            }`}
          >
            <item.icon className="h-6 w-6" />
            <span className="hidden sm:block ml-4">{item.label}</span>
          </button>
        ))}
      </nav>
       <div className="px-4 mb-4">
          <label htmlFor="language-select" className="hidden sm:block text-xs font-medium text-gray-500 mb-1">Language</label>
           <select 
            id="language-select" 
            value={language} 
            onChange={(e) => setLanguage(e.target.value as any)}
            className="w-full p-2 text-sm border-gray-300 rounded-md focus:ring-brand-blue focus:border-brand-blue"
           >
              {Object.entries(languageOptions).map(([code, name]) => (
                <option key={code} value={code}>{name}</option>
              ))}
           </select>
        </div>
      <div className="p-4 border-t">
        <div className="flex items-center justify-center sm:justify-start">
          <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
            <RecordsIcon className="h-6 w-6 text-gray-500" />
          </div>
          <div className="hidden sm:block ml-3">
            <p className="text-sm font-semibold text-gray-800">{user?.name || 'Patient'}</p>
            <p className="text-xs text-gray-500 truncate">{user?.email}</p>
          </div>
        </div>
         <button
          onClick={onLogout}
          className="flex items-center justify-center sm:justify-start p-3 w-full text-sm font-medium rounded-lg transition-colors duration-200 text-gray-600 hover:bg-gray-100 hover:text-gray-900 mt-4"
        >
          <LogoutIcon className="h-6 w-6" />
          <span className="hidden sm:block ml-4">Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
