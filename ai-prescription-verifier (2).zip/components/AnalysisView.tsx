import React, { useState, useCallback, useRef, useEffect } from 'react';
import { AnalysisResult, ChatMessage, InteractionLevel, PatientDraft } from '../types';
import { analyzePrescription, sendMessageToChat } from '../services/geminiService';
import { SafeIcon, WarningIcon, SevereIcon, UploadIcon, Spinner, AnalysisIcon, HeartIcon, PharmacyIcon, LifestyleIcon, ClockIcon, SwapIcon } from './icons';

// @ts-ignore - Tesseract is loaded from a script tag
const { Tesseract } = window;

interface AnalysisViewProps {
    addDraft: (draft: PatientDraft) => void;
    language: string;
    patientUser: { name: string; email: string };
}

const AnalysisView: React.FC<AnalysisViewProps> = ({ addDraft, language, patientUser }) => {
    const [patientName, setPatientName] = useState<string>('');
    const [patientAge, setPatientAge] = useState<string>('');
    const [patientGender, setPatientGender] = useState<string>('Female');
    const [allergies, setAllergies] = useState<string>('');
    const [conditions, setConditions] = useState<string>('');
    
    const [file, setFile] = useState<File | null>(null);
    const [textInput, setTextInput] = useState<string>('');
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
    
    const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
    const [chatInput, setChatInput] = useState<string>('');
    const [isChatLoading, setIsChatLoading] = useState<boolean>(false);

    const [ocrStatus, setOcrStatus] = useState('');
    const [ocrProgress, setOcrProgress] = useState(0);
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        setPatientName(patientUser.name);
    }, [patientUser]);

    const runOCR = async (file: File) => {
        if (!Tesseract) {
            setError('OCR library is not loaded.');
            return;
        }
        setOcrStatus('Initializing OCR...');
        setOcrProgress(0);
        setTextInput('');

        const worker = await Tesseract.createWorker({
            logger: (m: any) => {
                if (m.status === 'recognizing text') {
                    setOcrStatus(`Recognizing text...`);
                    setOcrProgress(m.progress * 100);
                }
            },
        });

        try {
            await worker.loadLanguage('eng');
            await worker.initialize('eng');
            const { data: { text } } = await worker.recognize(file);
            setTextInput(text);
            setOcrStatus('Text successfully extracted!');
        } catch (err) {
            console.error(err);
            setError('Failed to extract text from image.');
            setOcrStatus('OCR failed.');
        } finally {
            await worker.terminate();
            setOcrProgress(100);
        }
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = event.target.files?.[0];
        if (selectedFile) {
            setFile(selectedFile);
            setOcrStatus('');
            setOcrProgress(0);
            setTextInput('');
            setImagePreview(null);

            if (selectedFile.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onloadend = () => {
                    setImagePreview(reader.result as string);
                };
                reader.readAsDataURL(selectedFile);
                runOCR(selectedFile);
            } else if (selectedFile.type === 'text/plain' || selectedFile.type === 'application/pdf') {
                 if (selectedFile.type === 'text/plain') {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        setTextInput(e.target?.result as string);
                    };
                    reader.readAsText(selectedFile);
                } else {
                    setTextInput(`(File: ${selectedFile.name} - content will be processed by AI)`);
                }
            }
        }
    };

    const handleAnalyze = async () => {
        if (!file && !textInput.trim()) {
            setError('Please upload a prescription file or enter prescription text.');
            return;
        }
        if (!patientAge || !patientName) {
            setError('Please enter the patient\'s name and age.');
            return;
        }
        
        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);

        try {
            const result = await analyzePrescription(file, textInput, patientName, parseInt(patientAge), patientGender, allergies, conditions, language);
            setAnalysisResult(result);
            setChatMessages([
                { role: 'model', text: 'Hello! I\'ve analyzed the prescription. How can I help you further?' }
            ]);
            
            // Save to drafts
            const newDraft: PatientDraft = {
                id: `DRAFT-${Date.now()}`,
                date: new Date().toLocaleDateString(),
                patient: `${patientName}, Age ${patientAge}, ${patientGender}`,
                prescriptionSummary: result.drugs.map(d => d.name).join(', ') || 'N/A',
                analysis: result
            };
            addDraft(newDraft);

        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred during analysis.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleDownloadAnalysis = () => {
        if (!analysisResult) return;
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(analysisResult, null, 2));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", `analysis-${Date.now()}.json`);
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    };

    const handleChatSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!chatInput.trim() || isChatLoading || !analysisResult) return;
        
        const newUserMessage: ChatMessage = { role: 'user', text: chatInput };
        setChatMessages(prev => [...prev, newUserMessage]);
        setChatInput('');
        setIsChatLoading(true);
        
        try {
            const fullHistory: ChatMessage[] = [...chatMessages, newUserMessage];
            const stream = await sendMessageToChat(fullHistory, analysisResult);

            let modelResponse = '';
            setChatMessages(prev => [...prev, { role: 'model', text: '' }]);
            
            for await (const chunk of stream) {
                modelResponse += chunk.text;
                setChatMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = { role: 'model', text: modelResponse };
                    return newMessages;
                });
            }
        } catch (err) {
            const errorText = err instanceof Error ? err.message : 'An error occurred in chat.';
            setChatMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = { role: 'model', text: `Sorry, I encountered an error: ${errorText}` };
                return newMessages;
            });
        } finally {
            setIsChatLoading(false);
        }
    };
    
    // Result display components
    const AlertCard: React.FC<{ alert: AnalysisResult['interactionAlert'] }> = ({ alert }) => {
        const config = {
            [InteractionLevel.Safe]: {
                icon: <SafeIcon className="h-8 w-8 text-brand-green-dark" />,
                bgColor: 'bg-brand-green-light',
                textColor: 'text-brand-green-dark',
                title: 'No Interactions Found'
            },
            [InteractionLevel.Warning]: {
                icon: <WarningIcon className="h-8 w-8 text-brand-yellow-dark" />,
                bgColor: 'bg-brand-yellow-light',
                textColor: 'text-brand-yellow-dark',
                title: 'Potential Interaction Warning'
            },
            [InteractionLevel.Severe]: {
                icon: <SevereIcon className="h-8 w-8 text-brand-red-dark" />,
                bgColor: 'bg-brand-red-light',
                textColor: 'text-brand-red-dark',
                title: 'Severe Interaction Alert'
            },
        };

        const { icon, bgColor, textColor, title } = config[alert.level];

        return (
            <div className={`rounded-lg p-4 flex items-start space-x-4 ${bgColor}`}>
                <div className="flex-shrink-0">{icon}</div>
                <div className={textColor}>
                    <h3 className="font-bold text-lg">{title}</h3>
                    <p className="text-sm">{alert.explanation}</p>
                </div>
            </div>
        );
    };

    const HealthScoreCard: React.FC<{ score: number }> = ({ score }) => {
        const getScoreColor = () => {
            if (score > 80) return 'text-brand-green-dark';
            if (score > 50) return 'text-brand-yellow-dark';
            return 'text-brand-red-dark';
        };
        const circumference = 2 * Math.PI * 50;
        const strokeDashoffset = circumference - (score / 100) * circumference;

        return (
            <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Prescription Health Score</h3>
                <div className="relative w-32 h-32">
                    <svg className="w-full h-full" viewBox="0 0 120 120">
                        <circle className="text-gray-200" strokeWidth="10" stroke="currentColor" fill="transparent" r="50" cx="60" cy="60" />
                        <circle className={`${getScoreColor()} transition-all duration-1000 ease-in-out`} strokeWidth="10" strokeDasharray={circumference} strokeDashoffset={strokeDashoffset} strokeLinecap="round" stroke="currentColor" fill="transparent" r="50" cx="60" cy="60" style={{ transform: 'rotate(-90deg)', transformOrigin: '50% 50%' }} />
                    </svg>
                    <span className={`absolute inset-0 flex items-center justify-center text-4xl font-bold ${getScoreColor()}`}>{score}</span>
                </div>
                <p className="text-sm text-gray-600 mt-2 text-center">A measure of safety and suitability.</p>
            </div>
        );
    };
    
    const SideEffectsCard: React.FC<{ sideEffects: AnalysisResult['sideEffects'] }> = ({ sideEffects }) => (
        <div className="bg-white p-4 rounded-lg border">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Potential Side Effects</h3>
            <div className="space-y-3">
                <div>
                    <h4 className="font-semibold text-yellow-700">Common</h4>
                    <ul className="list-disc list-inside text-sm text-gray-600 pl-2">
                        {sideEffects.common.map((effect, i) => <li key={i}>{effect}</li>)}
                    </ul>
                </div>
                <div>
                    <h4 className="font-semibold text-red-700">Serious (Consult a Doctor)</h4>
                    <ul className="list-disc list-inside text-sm text-gray-600 pl-2">
                        {sideEffects.serious.map((effect, i) => <li key={i}>{effect}</li>)}
                    </ul>
                </div>
            </div>
        </div>
    );
    
     const MedicineAvailabilityCard: React.FC<{ data: AnalysisResult['medicineAvailability'] }> = ({ data }) => (
        <div className="col-span-1 lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center gap-3 mb-4">
                <PharmacyIcon className="w-8 h-8 text-brand-blue" />
                <h2 className="text-2xl font-semibold text-gray-700">Medicine Availability & Pricing</h2>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                        <tr>
                            <th scope="col" className="px-4 py-3">Drug</th>
                            <th scope="col" className="px-4 py-3">Pharmacy</th>
                            <th scope="col" className="px-4 py-3">Price</th>
                            <th scope="col" className="px-4 py-3">Availability</th>
                            <th scope="col" className="px-4 py-3">Distance</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((item, index) => (
                            <tr key={index} className="bg-white border-b hover:bg-gray-50">
                                <th scope="row" className="px-4 py-4 font-medium text-gray-900 whitespace-nowrap">{item.drugName}</th>
                                <td className="px-4 py-4">{item.pharmacy}</td>
                                <td className="px-4 py-4">{item.price}</td>
                                <td className="px-4 py-4">
                                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                        item.availability === 'In Stock' ? 'bg-green-100 text-green-800' :
                                        item.availability === 'Low Stock' ? 'bg-yellow-100 text-yellow-800' :
                                        'bg-red-100 text-red-800'
                                    }`}>
                                        {item.availability}
                                    </span>
                                </td>
                                <td className="px-4 py-4">{item.distance}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
    
    const LifestyleSuggestionsCard: React.FC<{ suggestions: string[] }> = ({ suggestions }) => (
         <div className="col-span-1 lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center gap-3 mb-4">
                <LifestyleIcon className="w-8 h-8 text-brand-green-dark" />
                <h2 className="text-2xl font-semibold text-gray-700">Health & Lifestyle Suggestions</h2>
            </div>
            <ul className="space-y-2 list-disc list-inside text-gray-700">
                {suggestions.map((tip, index) => <li key={index}>{tip}</li>)}
            </ul>
        </div>
    );

    const AlternativeSuggestionsCard: React.FC<{ suggestions: AnalysisResult['alternativeSuggestions'] }> = ({ suggestions }) => (
        <div className="col-span-1 lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center gap-3 mb-4">
                <SwapIcon className="w-8 h-8 text-brand-blue" />
                <h2 className="text-2xl font-semibold text-gray-700">Alternative Suggestions</h2>
            </div>
            <div className="space-y-4">
                {suggestions.map((alt, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg border">
                        <div className="grid grid-cols-2 gap-4 items-center">
                            <div>
                                <p className="text-xs text-gray-500">Original Drug</p>
                                <p className="font-semibold text-red-600">{alt.originalDrug}</p>
                            </div>
                            <div className="text-right">
                                 <p className="text-xs text-gray-500">Suggested Alternative</p>
                                <p className="font-semibold text-green-600">{alt.alternativeDrug}</p>
                            </div>
                        </div>
                        <p className="text-sm text-gray-600 mt-3 pt-3 border-t">
                            <span className="font-semibold">Reason:</span> {alt.reason}
                        </p>
                    </div>
                ))}
            </div>
        </div>
    );
    
    const MedicineRemindersCard: React.FC<{ reminders: AnalysisResult['medicineReminders'] }> = ({ reminders }) => (
         <div className="col-span-1 lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center gap-3 mb-4">
                <ClockIcon className="w-8 h-8 text-brand-blue" />
                <h2 className="text-2xl font-semibold text-gray-700">Medicine Reminder Schedule</h2>
            </div>
            <div className="space-y-3">
                {reminders.map((reminder, index) => (
                    <div key={index} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
                        <div>
                            <p className="font-bold text-brand-blue-dark">{reminder.drugName}</p>
                            <p className="text-sm text-gray-700">
                                Take at: <span className="font-semibold">{reminder.reminderTimes.join(', ')}</span>
                            </p>
                            <p className="text-xs text-gray-500">{reminder.instructions}</p>
                        </div>
                        <button 
                            onClick={() => alert(`Simulating adding a reminder for ${reminder.drugName} to your calendar.`)}
                            className="mt-3 sm:mt-0 px-3 py-1 bg-white text-brand-blue text-sm font-semibold rounded-full border border-brand-blue hover:bg-brand-blue-light transition-colors"
                        >
                            Add to Calendar
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );


    return (
        <div className="max-w-7xl mx-auto space-y-8">
            <header>
                <h1 className="text-4xl font-bold text-gray-800">Prescription Analysis</h1>
                <p className="mt-2 text-lg text-gray-600">Upload a prescription to verify dosage, check for interactions, and receive suggestions.</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left Column: Upload and Patient Info */}
                <div className="bg-white p-6 rounded-xl shadow-md space-y-6">
                    <h2 className="text-2xl font-semibold text-gray-700 border-b pb-3">1. Patient & Prescription Details</h2>
                    
                    {/* Patient Info */}
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <div>
                            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Patient Name</label>
                            <input type="text" id="name" value={patientName} onChange={e => setPatientName(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue" placeholder="e.g., John Smith" />
                        </div>
                        <div>
                            <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-1">Patient Age</label>
                            <input type="number" id="age" value={patientAge} onChange={e => setPatientAge(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue" placeholder="e.g., 45" />
                        </div>
                        <div className="md:col-span-2">
                             <label className="block text-sm font-medium text-gray-700 mb-2">Patient Gender</label>
                             <div className="flex items-center space-x-2">
                                {['Female', 'Male', 'Other'].map((gender) => (
                                    <button
                                        key={gender}
                                        type="button"
                                        onClick={() => setPatientGender(gender)}
                                        className={`px-4 py-2 text-sm font-medium rounded-md border transition-colors w-full ${
                                            patientGender === gender
                                                ? 'bg-brand-blue text-white border-brand-blue'
                                                : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                                        }`}
                                    >
                                        {gender}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                     <div>
                        <label htmlFor="allergies" className="block text-sm font-medium text-gray-700 mb-1">Known Allergies</label>
                        <input type="text" id="allergies" value={allergies} onChange={e => setAllergies(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue" placeholder="e.g., Penicillin, Aspirin" />
                    </div>
                     <div>
                        <label htmlFor="conditions" className="block text-sm font-medium text-gray-700 mb-1">Pre-existing Conditions</label>
                        <input type="text" id="conditions" value={conditions} onChange={e => setConditions(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue" placeholder="e.g., Diabetes, High Blood Pressure" />
                    </div>
                    
                    {/* File Upload */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Upload Prescription File</label>
                         <div onClick={() => fileInputRef.current?.click()} className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer hover:border-brand-blue">
                            <div className="space-y-1 text-center">
                                {imagePreview ? (
                                    <img src={imagePreview} alt="Prescription preview" className="mx-auto h-32 w-auto object-contain rounded-md" />
                                ) : (
                                    <>
                                        <UploadIcon className="mx-auto h-12 w-12 text-gray-400" />
                                        <div className="flex text-sm text-gray-600">
                                            <p className="pl-1">or drag and drop</p>
                                        </div>
                                    </>
                                )}
                                <p className="text-xs text-gray-500">{file ? file.name : 'PNG, JPG, PDF, TXT up to 10MB'}</p>
                            </div>
                        </div>
                        <input ref={fileInputRef} id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*,application/pdf,.txt" />
                    </div>
                    
                     {ocrStatus && (
                        <div>
                            <p className="text-sm font-medium text-gray-700">{ocrStatus}</p>
                            <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
                                <div className="bg-brand-blue h-2.5 rounded-full" style={{ width: `${ocrProgress}%` }}></div>
                            </div>
                        </div>
                     )}

                    {/* Text Input */}
                    <div>
                        <label htmlFor="text-input" className="block text-sm font-medium text-gray-700">Or Paste Prescription Text (Auto-filled by OCR)</label>
                        <textarea id="text-input" rows={4} value={textInput} onChange={e => setTextInput(e.target.value)} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-brand-blue focus:border-brand-blue" placeholder="e.g., Atorvastatin 20mg, take one tablet daily..."></textarea>
                    </div>

                    {error && <p className="text-sm text-red-600">{error}</p>}
                    
                    <button onClick={handleAnalyze} disabled={isLoading} className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-brand-blue hover:bg-brand-blue-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-blue disabled:bg-gray-400">
                        {isLoading && <Spinner />}
                        {isLoading ? 'Analyzing...' : 'Analyze Prescription'}
                    </button>
                </div>

                {/* Right Column: Results */}
                <div className="space-y-6">
                     <div className="bg-white p-6 rounded-xl shadow-md">
                         <div className="flex justify-between items-center border-b pb-3 mb-4">
                            <h2 className="text-2xl font-semibold text-gray-700">2. Analysis Results</h2>
                            {analysisResult && (
                                <button onClick={handleDownloadAnalysis} className="text-sm font-medium text-brand-blue hover:underline">Download Record</button>
                            )}
                         </div>
                        {isLoading ? (
                            <div className="flex flex-col items-center justify-center h-full text-gray-500">
                                <Spinner />
                                <p className="mt-2 text-lg">Analyzing your prescription...</p>
                                <p className="text-sm">This may take a moment.</p>
                            </div>
                        ) : analysisResult ? (
                            <div className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <HealthScoreCard score={analysisResult.healthScore} />
                                    <SideEffectsCard sideEffects={analysisResult.sideEffects} />
                                </div>

                                <AlertCard alert={analysisResult.interactionAlert} />
                                
                                <div>
                                    <h3 className="text-lg font-semibold text-gray-800 mb-2">Parsed Drugs</h3>
                                    <ul className="space-y-3">
                                    {analysisResult.drugs.map((drug, index) => (
                                        <li key={index} className="p-3 bg-gray-50 rounded-md border">
                                            <p className="font-bold text-brand-blue-dark">{drug.name}</p>
                                            <p className="text-sm text-gray-600"><strong>Dosage:</strong> {drug.dosage}</p>
                                            <p className="text-sm text-gray-600"><strong>Frequency:</strong> {drug.frequency}</p>
                                        </li>
                                    ))}
                                    </ul>
                                </div>

                                <div>
                                    <h3 className="text-lg font-semibold text-gray-800 mb-2">Dosage Verification</h3>
                                    <div className={`p-3 rounded-md border ${analysisResult.dosageVerification.isCorrect ? 'bg-brand-green-light border-brand-green text-brand-green-dark' : 'bg-brand-red-light border-brand-red-dark text-brand-red-dark'}`}>
                                        <p className="font-semibold">{analysisResult.dosageVerification.isCorrect ? 'Dosage appears correct' : 'Dosage may need review'}</p>
                                        <p className="text-sm">{analysisResult.dosageVerification.explanation}</p>
                                    </div>
                                </div>

                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center h-full text-gray-500">
                                <AnalysisIcon className="h-16 w-16 mb-4"/>
                                <p className="text-lg">Your analysis results will appear here.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {analysisResult && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                     <MedicineAvailabilityCard data={analysisResult.medicineAvailability} />
                     <LifestyleSuggestionsCard suggestions={analysisResult.lifestyleSuggestions} />
                     {analysisResult.alternativeSuggestions.length > 0 && <AlternativeSuggestionsCard suggestions={analysisResult.alternativeSuggestions} />}
                     {analysisResult.medicineReminders.length > 0 && <MedicineRemindersCard reminders={analysisResult.medicineReminders} />}
                </div>
            )}


            {/* Chatbot Section */}
             {analysisResult && (
                <div className="bg-white p-6 rounded-xl shadow-md mt-8">
                    <h2 className="text-2xl font-semibold text-gray-700 border-b pb-3 mb-4">3. Ask Follow-up Questions</h2>
                    <div className="flex flex-col h-[500px]">
                        <div className="flex-1 overflow-y-auto p-4 bg-gray-50 rounded-t-lg space-y-4">
                            {chatMessages.map((msg, index) => (
                                <div key={index} className={`flex items-end gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    {msg.role === 'model' && <div className="w-8 h-8 rounded-full bg-brand-blue flex items-center justify-center text-white font-bold text-sm flex-shrink-0">AI</div>}
                                    <div className={`max-w-lg p-3 rounded-2xl ${msg.role === 'user' ? 'bg-brand-blue text-white rounded-br-none' : 'bg-brand-blue text-white rounded-bl-none'}`}>
                                        <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                                    </div>
                                    {msg.role === 'user' && <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 font-bold text-sm flex-shrink-0">U</div>}
                                </div>
                            ))}
                            {isChatLoading && chatMessages[chatMessages.length - 1]?.role === 'user' && (
                                <div className="flex items-end gap-2 justify-start">
                                    <div className="w-8 h-8 rounded-full bg-brand-blue flex items-center justify-center text-white font-bold text-sm flex-shrink-0">AI</div>
                                    <div className="max-w-lg p-3 rounded-2xl bg-white border rounded-bl-none">
                                        <div className="flex items-center">
                                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s] mx-1"></div>
                                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                        <form onSubmit={handleChatSubmit} className="border-t p-4 bg-white rounded-b-lg flex items-center gap-4">
                            <input
                                type="text"
                                value={chatInput}
                                onChange={(e) => setChatInput(e.target.value)}
                                placeholder="Ask about dosages, side effects, etc..."
                                className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:ring-brand-blue focus:border-brand-blue"
                                disabled={isChatLoading}
                            />
                            <button type="submit" disabled={isChatLoading || !chatInput.trim()} className="px-4 py-2 bg-brand-blue text-white rounded-full hover:bg-brand-blue-dark disabled:bg-gray-400">
                                Send
                            </button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AnalysisView;