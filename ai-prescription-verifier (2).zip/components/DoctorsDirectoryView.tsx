import React, { useState } from 'react';
import { CheckIcon, CloseIcon, LocationMarkerIcon } from './icons';

interface Doctor {
  id: number;
  name: string;
  specialty: string;
  rating: number;
  reviews: number;
  bio: string;
  phone: string;
  email: string;
  location: string;
  availability: Record<string, string>;
}

const doctors: Doctor[] = [
  {
    id: 1,
    name: 'Dr. Priya Sharma',
    specialty: 'Cardiologist',
    rating: 4.9,
    reviews: 215,
    bio: 'Dr. Sharma is a board-certified cardiologist with over 15 years of experience in treating heart conditions. She is dedicated to providing personalized care and uses the latest medical advancements to ensure the best outcomes for her patients.',
    phone: '+91 98765 43210',
    email: 'priya.sharma@medclinic.com',
    location: 'Hyderabad',
    availability: {
        'Monday': '9:00 AM - 5:00 PM',
        'Tuesday': '9:00 AM - 1:00 PM',
        'Wednesday': '10:00 AM - 6:00 PM',
        'Thursday': '9:00 AM - 5:00 PM',
        'Friday': 'Not Available',
        'Saturday': '10:00 AM - 2:00 PM',
        'Sunday': 'Not Available',
    }
  },
  {
    id: 2,
    name: 'Dr. Rohan Verma',
    specialty: 'Pediatrician',
    rating: 4.8,
    reviews: 189,
    bio: 'With a friendly and compassionate approach, Dr. Verma has been caring for children for over a decade. He believes in building strong relationships with families to support healthy development from infancy through adolescence.',
    phone: '+91 99887 76655',
    email: 'rohan.verma@medclinic.com',
    location: 'Hyderabad',
    availability: {
        'Monday': '10:00 AM - 6:00 PM',
        'Tuesday': '10:00 AM - 6:00 PM',
        'Wednesday': '9:00 AM - 1:00 PM',
        'Thursday': 'Not Available',
        'Friday': '10:00 AM - 6:00 PM',
        'Saturday': '9:00 AM - 12:00 PM',
        'Sunday': 'Not Available',
    }
  },
  {
    id: 3,
    name: 'Dr. Anjali Desai',
    specialty: 'Dermatologist',
    rating: 4.9,
    reviews: 302,
    bio: 'Dr. Desai specializes in both medical and cosmetic dermatology. She is renowned for her expertise in treating complex skin conditions and her commitment to helping patients achieve healthy, radiant skin.',
    phone: '+91 91234 56789',
    email: 'anjali.desai@medclinic.com',
    location: 'Hyderabad',
    availability: {
        'Monday': 'Not Available',
        'Tuesday': '11:00 AM - 7:00 PM',
        'Wednesday': '11:00 AM - 7:00 PM',
        'Thursday': '10:00 AM - 4:00 PM',
        'Friday': '11:00 AM - 7:00 PM',
        'Saturday': '11:00 AM - 3:00 PM',
        'Sunday': 'Not Available',
    }
  },
  {
    id: 4,
    name: 'Dr. Vikram Singh',
    specialty: 'Orthopedic Surgeon',
    rating: 4.7,
    reviews: 154,
    bio: 'Dr. Singh is a leading orthopedic surgeon with a focus on sports injuries and joint replacement. He is passionate about restoring mobility and improving the quality of life for his patients through surgical and non-surgical treatments.',
    phone: '+91 95555 12345',
    email: 'vikram.singh@medclinic.com',
    location: 'Hyderabad',
    availability: {
        'Monday': '8:00 AM - 4:00 PM',
        'Tuesday': 'Not Available',
        'Wednesday': '8:00 AM - 4:00 PM',
        'Thursday': '1:00 PM - 7:00 PM',
        'Friday': '8:00 AM - 4:00 PM',
        'Saturday': 'Not Available',
        'Sunday': 'Not Available',
    }
  },
];

const StarRating: React.FC<{ rating: number }> = ({ rating }) => {
  const stars = Array.from({ length: 5 }, (_, i) => (
    <svg key={i} className={`w-4 h-4 ${i < Math.round(rating) ? 'text-yellow-400' : 'text-gray-300'}`} fill="currentColor" viewBox="0 0 20 20">
      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.955a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.445a1 1 0 00-.364 1.118l1.287 3.955c.3.921-.755 1.688-1.54 1.118l-3.367-2.445a1 1 0 00-1.175 0l-3.367 2.445c-.784.57-1.838-.197-1.539-1.118l1.287-3.955a1 1 0 00-.364-1.118L2.34 9.382c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69L9.049 2.927z" />
    </svg>
  ));
  return <div className="flex items-center">{stars}</div>;
};

const DoctorCard: React.FC<{
  doctor: Doctor;
  onViewProfile: (doctor: Doctor) => void;
  onBookAppointment: (doctor: Doctor) => void;
  onCheckAvailability: (doctor: Doctor) => void;
}> = ({ doctor, onViewProfile, onBookAppointment, onCheckAvailability }) => {
  const initials = doctor.name.replace('Dr. ', '').split(' ').map(n => n[0]).join('');

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
      <div className="md:flex">
        <div className="md:flex-shrink-0">
          <div className="h-48 w-full md:w-48 bg-brand-blue-light flex items-center justify-center">
            <span className="text-5xl font-bold text-brand-blue-dark">{initials}</span>
          </div>
        </div>
        <div className="p-6 flex flex-col justify-between">
          <div>
            <div className="uppercase tracking-wide text-sm text-brand-blue font-semibold">{doctor.specialty}</div>
            <h2 className="block mt-1 text-lg leading-tight font-bold text-black">{doctor.name}</h2>
            <div className="mt-2 flex items-center">
              <StarRating rating={doctor.rating} />
              <span className="text-gray-600 text-sm ml-2">{doctor.rating.toFixed(1)} ({doctor.reviews} reviews)</span>
            </div>
             <p className="mt-2 flex items-center text-sm text-gray-600">
                <LocationMarkerIcon className="h-4 w-4 mr-1 text-gray-400" />
                {doctor.location}
            </p>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              onClick={() => onViewProfile(doctor)}
              className="px-3 py-1.5 bg-white text-brand-blue text-xs font-semibold rounded-full border border-brand-blue hover:bg-brand-blue-light transition-colors"
            >
              View Profile
            </button>
            <button
              onClick={() => onCheckAvailability(doctor)}
              className="px-3 py-1.5 bg-white text-brand-green-dark text-xs font-semibold rounded-full border border-brand-green-dark hover:bg-brand-green-light transition-colors"
            >
              Check Availability
            </button>
            <button
              onClick={() => onBookAppointment(doctor)}
              className="px-3 py-1.5 bg-brand-blue text-white text-xs font-semibold rounded-full hover:bg-brand-blue-dark transition-colors"
            >
              Book Appointment
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const DoctorProfileModal: React.FC<{
  doctor: Doctor;
  onClose: () => void;
}> = ({ doctor, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-2xl max-w-lg w-full relative transform transition-all" role="dialog" aria-modal="true" aria-labelledby="modal-title">
                 <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600" aria-label="Close">
                    <CloseIcon className="h-6 w-6" />
                </button>
                <div className="p-8">
                    <h3 id="modal-title" className="text-2xl font-bold text-gray-900">{doctor.name}</h3>
                    <p className="text-md text-brand-blue font-medium">{doctor.specialty}</p>
                     <div className="mt-2 flex items-center">
                        <StarRating rating={doctor.rating} />
                        <span className="text-gray-600 text-sm ml-2">{doctor.rating.toFixed(1)} ({doctor.reviews} reviews)</span>
                    </div>
                    <p className="mt-4 text-gray-600 text-sm">{doctor.bio}</p>
                    <div className="mt-6 border-t pt-4 space-y-2">
                         <p className="text-sm text-gray-800"><strong>Email:</strong> {doctor.email}</p>
                         <p className="text-sm text-gray-800"><strong>Phone:</strong> {doctor.phone}</p>
                         <p className="text-sm text-gray-800"><strong>Location:</strong> {doctor.location}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};


const AppointmentConfirmationModal: React.FC<{
  doctor: Doctor;
  onClose: () => void;
}> = ({ doctor, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-2xl max-w-sm w-full p-8 text-center" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title">
                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
                    <CheckIcon className="h-6 w-6 text-green-600" />
                </div>
                <h3 id="confirm-title" className="mt-4 text-lg font-medium text-gray-900">Appointment Booked!</h3>
                <p className="mt-2 text-sm text-gray-600">
                    Your appointment with <strong>{doctor.name}</strong> has been successfully scheduled.
                </p>
                <div className="mt-6">
                    <button
                        type="button"
                        onClick={onClose}
                        className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-brand-blue text-base font-medium text-white hover:bg-brand-blue-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-blue sm:text-sm"
                    >
                        OK
                    </button>
                </div>
            </div>
        </div>
    );
};

const AvailabilityModal: React.FC<{
  doctor: Doctor;
  onClose: () => void;
}> = ({ doctor, onClose }) => {
    const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
            <div className="bg-white rounded-lg shadow-2xl max-w-md w-full relative p-6" role="dialog" aria-modal="true" aria-labelledby="avail-title">
                 <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600" aria-label="Close">
                    <CloseIcon className="h-6 w-6" />
                </button>
                <h3 id="avail-title" className="text-xl font-bold text-gray-900 mb-1">Availability</h3>
                <p className="text-sm text-gray-500 mb-4">for {doctor.name}</p>
                <div className="space-y-2 border-t pt-4">
                    {daysOfWeek.map(day => (
                        <div key={day} className="flex justify-between items-center p-2.5 rounded-md even:bg-gray-50">
                            <span className="font-semibold text-gray-700">{day}</span>
                            <span className={`text-sm font-medium px-2 py-0.5 rounded-full ${doctor.availability[day] === 'Not Available' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                                {doctor.availability[day]}
                            </span>
                        </div>
                    ))}
                </div>
                 <div className="mt-6 text-right">
                    <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-100 text-gray-700 text-sm font-semibold rounded-md hover:bg-gray-200 transition-colors">
                        Close
                    </button>
                </div>
            </div>
        </div>
    );
};


const MapCard: React.FC = () => (
    <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <h2 className="p-6 text-2xl font-bold text-gray-800">Nearby Doctors in Hyderabad</h2>
        <div className="w-full h-80 bg-gray-200">
            <iframe
                title="Doctors in Hyderabad"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                allowFullScreen
                src="https://maps.google.com/maps?q=hospitals%20in%20Hyderabad&t=&z=12&ie=UTF8&iwloc=&output=embed"
            ></iframe>
        </div>
    </div>
);


const DoctorsDirectoryView: React.FC = () => {
    const [selectedDoctorProfile, setSelectedDoctorProfile] = useState<Doctor | null>(null);
    const [selectedDoctorAvailability, setSelectedDoctorAvailability] = useState<Doctor | null>(null);
    const [bookingConfirmation, setBookingConfirmation] = useState<Doctor | null>(null);

    return (
        <div className="max-w-7xl mx-auto">
            <header className="mb-8">
                <h1 className="text-4xl font-bold text-gray-800">Doctors Directory</h1>
                <p className="mt-2 text-lg text-gray-600">Find and book appointments with our team of expert medical professionals.</p>
            </header>
            
            <MapCard />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {doctors.map(doctor => (
                    <DoctorCard
                        key={doctor.id}
                        doctor={doctor}
                        onViewProfile={setSelectedDoctorProfile}
                        onBookAppointment={setBookingConfirmation}
                        onCheckAvailability={setSelectedDoctorAvailability}
                    />
                ))}
            </div>

            {selectedDoctorProfile && (
                <DoctorProfileModal
                    doctor={selectedDoctorProfile}
                    onClose={() => setSelectedDoctorProfile(null)}
                />
            )}
            
            {selectedDoctorAvailability && (
                <AvailabilityModal
                    doctor={selectedDoctorAvailability}
                    onClose={() => setSelectedDoctorAvailability(null)}
                />
            )}

            {bookingConfirmation && (
                <AppointmentConfirmationModal
                    doctor={bookingConfirmation}
                    onClose={() => setBookingConfirmation(null)}
                />
            )}
        </div>
    );
};

export default DoctorsDirectoryView;