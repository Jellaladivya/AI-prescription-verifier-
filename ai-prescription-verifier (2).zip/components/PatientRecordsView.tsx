
import React from 'react';
import { PatientDraft } from '../types';

interface PatientRecordsViewProps {
    drafts: PatientDraft[];
}

const PatientRecordsView: React.FC<PatientRecordsViewProps> = ({ drafts }) => {
    
  const handlePrint = () => {
      window.print();
  };

  const handleDownload = (draft: PatientDraft) => {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(draft.analysis, null, 2));
      const downloadAnchorNode = document.createElement('a');
      downloadAnchorNode.setAttribute("href", dataStr);
      downloadAnchorNode.setAttribute("download", `${draft.id}.json`);
      document.body.appendChild(downloadAnchorNode);
      downloadAnchorNode.click();
      downloadAnchorNode.remove();
  };

  return (
    <div className="max-w-7xl mx-auto">
      <header className="mb-8">
        <h1 className="text-4xl font-bold text-gray-800">Patient Drafts</h1>
        <p className="mt-2 text-lg text-gray-600">Review, download, or print your past prescription analyses and chat histories.</p>
      </header>
      <div className="space-y-6">
        {drafts.length > 0 ? (
            drafts.map((draft) => (
                <div key={draft.id} className="bg-white p-6 rounded-xl shadow-md">
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b pb-4 mb-4">
                        <div>
                            <h2 className="text-xl font-semibold text-gray-800">{draft.id}</h2>
                            <p className="text-sm text-gray-500">Date: {draft.date}</p>
                        </div>
                        <span className="mt-2 sm:mt-0 px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Analysis Complete
                        </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h3 className="font-semibold text-gray-700 mb-2">Details</h3>
                            <p className="text-sm text-gray-600"><span className="font-medium">Patient:</span> {draft.patient}</p>
                            <p className="text-sm text-gray-600"><span className="font-medium">Prescription:</span> {draft.prescriptionSummary}</p>
                        </div>
                        <div>
                            <h3 className="font-semibold text-gray-700 mb-2">Analysis Snippet</h3>
                            <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md max-h-24 overflow-y-auto">
                                <p><strong>Health Score:</strong> {draft.analysis.healthScore}</p>
                                <p><strong>Interaction Alert:</strong> {draft.analysis.interactionAlert.level}</p>
                            </div>
                        </div>
                    </div>
                    <div className="flex justify-end space-x-3 mt-6 border-t pt-4">
                        <button onClick={() => handleDownload(draft)} className="text-sm font-medium text-brand-blue hover:underline">Download Record</button>
                        <button onClick={handlePrint} className="px-4 py-2 bg-brand-blue text-white rounded-md text-sm hover:bg-brand-blue-dark">Print</button>
                    </div>
                </div>
            ))
        ) : (
            <div className="text-center py-12 bg-white rounded-xl shadow-md">
                <h3 className="text-xl font-semibold text-gray-700">No Drafts Found</h3>
                <p className="text-gray-500 mt-2">Your saved prescription analyses will appear here.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default PatientRecordsView;